-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 22, 2018 at 02:34 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `kecamatan`
--

DROP TABLE IF EXISTS `kecamatan`;
CREATE TABLE IF NOT EXISTS `kecamatan` (
  `id_kec` int(11) NOT NULL,
  `kec` text NOT NULL,
  `desa` text NOT NULL,
  PRIMARY KEY (`id_kec`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kecamatan`
--

INSERT INTO `kecamatan` (`id_kec`, `kec`, `desa`) VALUES
(1, 'Ajung', 'Ajung (68175)'),
(2, 'Ajung', 'Klompangan (68175)'),
(3, 'Ajung', 'Mangaran (68175)'),
(4, 'Ajung', 'Pancakarya (68175)'),
(5, 'Ajung', 'Rowo Indah (68175)'),
(6, 'Ajung', 'Sukamakmur (68175)'),
(7, 'Ajung', 'Wirowongso (68175)'),
(8, 'Ambulu', 'Karang Anyar (68132)'),
(9, 'Ambulu', 'Ambulu (68172)'),
(10, 'Ambulu', 'Andongsari (68172)'),
(11, 'Ambulu', 'Pontang (68172)'),
(12, 'Ambulu', 'Sabrang (68172)'),
(13, 'Ambulu', 'Sumberrejo (68172)'),
(14, 'Ambulu', 'Tegalsari (68172)'),
(15, 'Arjasa', 'Arjasa (68191)'),
(16, 'Arjasa', 'Biting (68191)'),
(17, 'Arjasa', 'Candijati (68191)'),
(18, 'Arjasa', 'Darsono (68191)'),
(19, 'Arjasa', 'Kamal (68191)'),
(20, 'Arjasa', 'Kemuningllor (68191)'),
(21, 'Balung', 'Balung Kidul (68161)'),
(22, 'Balung', 'Balung Kulon (68161)'),
(23, 'Balung', 'Balung Lor (68161)'),
(24, 'Balung', 'Curahlele (68161)'),
(25, 'Balung', 'Gumelar (68161)'),
(26, 'Balung', 'Karang Duren (68161)'),
(27, 'Balung', 'Karang Semanding (68161)'),
(28, 'Balung', 'Tutul (68161)'),
(29, 'Bangsalsari', 'Badean (68154)'),
(30, 'Bangsalsari', 'Bangsalsari (68154)'),
(31, 'Bangsalsari', 'Banjarsari (68154)'),
(32, 'Bangsalsari', 'Curah Kalong (68154)'),
(33, 'Bangsalsari', 'Gambirono (68154)'),
(34, 'Bangsalsari', 'Karangsono (68154)'),
(35, 'Bangsalsari', 'Langkap (68154)'),
(36, 'Bangsalsari', 'Petung (68154)'),
(37, 'Bangsalsari', 'Sukorejo (68154)'),
(38, 'Bangsalsari', 'Tisnogambar (68154)'),
(39, 'Bangsalsari', 'Tugusari (68154)'),
(40, 'Gumukmas', 'Bagorejo (68165)'),
(41, 'Gumukmas', 'Gumukmas (68165)'),
(42, 'Gumukmas', 'Karang Rejo (68165)'),
(43, 'Gumukmas', 'Kepanjen (68165)'),
(44, 'Gumukmas', 'Mayangan (68165)'),
(45, 'Gumukmas', 'Menampu (68165)'),
(46, 'Gumukmas', 'Purwoasri (68165)'),
(47, 'Gumukmas', 'Tembokrejo (68165)'),
(48, 'Jelbuk', 'Jelbuk (68192)'),
(49, 'Jelbuk', 'Panduman (68192)'),
(50, 'Jelbuk', 'Suco Pangepok (68192)'),
(51, 'Jelbuk', 'Suger Kidul (68192)'),
(52, 'Jelbuk', 'Suko Jember (68192)'),
(53, 'Jelbuk', 'Sukowiryo (68192)'),
(54, 'Jenggawah', 'Cangkring (68171)'),
(55, 'Jenggawah', 'Jatimulyo (68171)'),
(56, 'Jenggawah', 'Jatisari (68171)'),
(57, 'Jenggawah', 'Jenggawah (68171)'),
(58, 'Jenggawah', 'Kemuning Sari Kidul (68171)'),
(59, 'Jenggawah', 'Kertonegoro (68171)'),
(60, 'Jenggawah', 'Seruni (68171)'),
(61, 'Jenggawah', 'Wonojati (68171)'),
(62, 'Jombang', 'Jombang (68168)'),
(63, 'Jombang', 'Keting (68168)'),
(64, 'Jombang', 'Ngampelrejo (68168)'),
(65, 'Jombang', 'Padomasan (68168)'),
(66, 'Jombang', 'Wringin Agung (68168)'),
(67, 'Kalisat', 'Plalangan (68113)'),
(68, 'Kalisat', 'Ajung (68193)'),
(69, 'Kalisat', 'Gambiran (68193)'),
(70, 'Kalisat', 'Glagahwero (68193)'),
(71, 'Kalisat', 'Gumuksari (68193)'),
(72, 'Kalisat', 'Kalisat (68193)'),
(73, 'Kalisat', 'Patempuran (68193)'),
(74, 'Kalisat', 'Sebanen (68193)'),
(75, 'Kalisat', 'Sukoreno (68193)'),
(76, 'Kalisat', 'Sumber Jeruk (68193)'),
(77, 'Kalisat', 'Sumber Kalong (68193)'),
(78, 'Kalisat', 'Sumber Ketempah (68193)'),
(79, 'Kaliwates', 'Jember Kidul (68131)'),
(80, 'Kaliwates', 'Tegal Besar (68132)'),
(81, 'Kaliwates', 'Kaliwates (68133)'),
(82, 'Kaliwates', 'Sempusari (68135)'),
(83, 'Kaliwates', 'Mangli (68136)'),
(84, 'Kaliwates', 'Kebon Agung (68137)'),
(85, 'Kaliwates', 'Kepatihan (68137)'),
(86, 'Kencong', 'Cakru (68167)'),
(87, 'Kencong', 'Kencong (68167)'),
(88, 'Kencong', 'Kraton (68167)'),
(89, 'Kencong', 'Paseban (68167)'),
(90, 'Kencong', 'Wonorejo (68167)'),
(91, 'Ledokombo', 'Karang Paiton (68196)'),
(92, 'Ledokombo', 'Ledokombo (68196)'),
(93, 'Ledokombo', 'Lembengan (68196)'),
(94, 'Ledokombo', 'Slateng (68196)'),
(95, 'Ledokombo', 'Sukogidri (68196)'),
(96, 'Ledokombo', 'Sumber Anget (68196)'),
(97, 'Ledokombo', 'Sumber Bulus (68196)'),
(98, 'Ledokombo', 'Sumber Lesung (68196)'),
(99, 'Ledokombo', 'Sumber Salak (68196)'),
(100, 'Ledokombo', 'Suren (68196)'),
(101, 'Mayang', 'Tegalrejo (68118)'),
(102, 'Mayang', 'Mayang (68182)'),
(103, 'Mayang', 'Mrawan (68182)'),
(104, 'Mayang', 'Seputih (68182)'),
(105, 'Mayang', 'Sidomukti (68182)'),
(106, 'Mayang', 'Sumber Kejayan (68182)'),
(107, 'Mayang', 'Tegal Waru (68182)'),
(108, 'Mumbulsari', 'Karangkedawung (68174)'),
(109, 'Mumbulsari', 'Kawangrejo (68174)'),
(110, 'Mumbulsari', 'Lampeji (68174)'),
(111, 'Mumbulsari', 'Lengkong (68174)'),
(112, 'Mumbulsari', 'Mumbulsari (68174)'),
(113, 'Mumbulsari', 'Suco (68174)'),
(114, 'Mumbulsari', 'Tamansari (68174)'),
(115, 'Pakusari', 'Bedadung (68181)'),
(116, 'Pakusari', 'Jatian (68181)'),
(117, 'Pakusari', 'Kertosari (68181)'),
(118, 'Pakusari', 'Pakusari (68181)'),
(119, 'Pakusari', 'Patemon (68181)'),
(120, 'Pakusari', 'Subo (68181)'),
(121, 'Pakusari', 'Sumber Pinang (68181)'),
(122, 'Panti', 'Glagahwero (68153)'),
(123, 'Panti', 'Kemiri (68153)'),
(124, 'Panti', 'Kemuningsari Lor (68153)'),
(125, 'Panti', 'Pakis (68153)'),
(126, 'Panti', 'Panti (68153)'),
(127, 'Panti', 'Serut (68153)'),
(128, 'Panti', 'Suci (68153)'),
(129, 'Patrang', 'Patrang (68111)'),
(130, 'Patrang', 'Baratan (68112)'),
(131, 'Patrang', 'Bintoro (68113)'),
(132, 'Patrang', 'Jumerto (68114)'),
(133, 'Patrang', 'Slawu (68116)'),
(134, 'Patrang', 'Gebang (68117)'),
(135, 'Patrang', 'Banjar Sengon (68118)'),
(136, 'Patrang', 'Jember Lor (68118)'),
(137, 'Puger', 'Bagon (68164)'),
(138, 'Puger', 'Grenden (68164)'),
(139, 'Puger', 'Jambearum (68164)'),
(140, 'Puger', 'Kasiyan (68164)'),
(141, 'Puger', 'Kasiyan Timur (68164)'),
(142, 'Puger', 'Mlokorejo (68164)'),
(143, 'Puger', 'Mojomulyo (68164)'),
(144, 'Puger', 'Mojosari (68164)'),
(145, 'Puger', 'Puger Kulon (68164)'),
(146, 'Puger', 'Puger Wetan (68164)'),
(147, 'Puger', 'Wonosari (68164)'),
(148, 'Puger', 'Wringin Telu (68164)'),
(149, 'Rambipuji', 'Curahmalang (68152)'),
(150, 'Rambipuji', 'Gugut (68152)'),
(151, 'Rambipuji', 'Kaliwining (68152)'),
(152, 'Rambipuji', 'Nogosari (68152)'),
(153, 'Rambipuji', 'Pecoro (68152)'),
(154, 'Rambipuji', 'Rambigundam (68152)'),
(155, 'Rambipuji', 'Rambipuji (68152)'),
(156, 'Rambipuji', 'Rowotamtu (68152)'),
(157, 'Semboro', 'Pondok Dalem (68157)'),
(158, 'Semboro', 'Pondok Joyo (68157)'),
(159, 'Semboro', 'Rejo Agung (68157)'),
(160, 'Semboro', 'Semboro (68157)'),
(161, 'Semboro', 'Sidomekar (68157)'),
(162, 'Semboro', 'Sidomulyo (68157)'),
(163, 'Silo', 'Garahan (68184)'),
(164, 'Silo', 'Harjomolyo (68184)'),
(165, 'Silo', 'Karangharjo (68184)'),
(166, 'Silo', 'Mulyorejo (68184)'),
(167, 'Silo', 'Pace (68184)'),
(168, 'Silo', 'Sempolan (68184)'),
(169, 'Silo', 'Sidomulyo (68184)'),
(170, 'Silo', 'Silo (68184)'),
(171, 'Silo', 'Sumberjati (68184)'),
(172, 'Sukorambi', 'Dukuh Mencek (68151)'),
(173, 'Sukorambi', 'Jubung (68151)'),
(174, 'Sukorambi', 'Karangpring (68151)'),
(175, 'Sukorambi', 'Kelungkung (68151)'),
(176, 'Sukorambi', 'Sukorambi (68151)'),
(177, 'Sukowono', 'Arjasa (68194)'),
(178, 'Sukowono', 'Balet Baru (68194)'),
(179, 'Sukowono', 'Dawuhan Mangli (68194)'),
(180, 'Sukowono', 'Mojogeni (68194)'),
(181, 'Sukowono', 'Pocangan (68194)'),
(182, 'Sukowono', 'Sukokerto (68194)'),
(183, 'Sukowono', 'Sukorejo (68194)'),
(184, 'Sukowono', 'Sukosari (68194)'),
(185, 'Sukowono', 'Sukowono (68194)'),
(186, 'Sukowono', 'Sumber Wringin (68194)'),
(187, 'Sukowono', 'Sumberdanti (68194)'),
(188, 'Sukowono', 'Sumberwaru (68194)'),
(189, 'SumberBaru', 'Gelang (68156)'),
(190, 'SumberBaru', 'Jambesari (68156)'),
(191, 'SumberBaru', 'Jamintoro (68156)'),
(192, 'SumberBaru', 'Jatiroto (68156)'),
(193, 'SumberBaru', 'Kaliglagah (68156)'),
(194, 'SumberBaru', 'Karang Bayat (68156)'),
(195, 'SumberBaru', 'Pringgowirawan (68156)'),
(196, 'SumberBaru', 'Rowo Tengah (68156)'),
(197, 'SumberBaru', 'Sumber Agung (68156)'),
(198, 'SumberBaru', 'Yosorati (68156)'),
(199, 'SumberJambe', 'Cumedak (68195)'),
(200, 'SumberJambe', 'Gunung Malang (68195)'),
(201, 'SumberJambe', 'Jambe Arum (68195)'),
(202, 'SumberJambe', 'Plereyan (68195)'),
(203, 'SumberJambe', 'Pringgondani (68195)'),
(204, 'SumberJambe', 'Randu Agung (68195)'),
(205, 'SumberJambe', 'Rowosari (68195)'),
(206, 'SumberJambe', 'Sumber Pakem (68195)'),
(207, 'SumberJambe', 'Sumberjambe (68195)'),
(208, 'SumberSari', 'Sumbersari (68121)'),
(209, 'SumberSari', 'Kebonsari (68122)'),
(210, 'SumberSari', 'Karangrejo (68124)'),
(211, 'SumberSari', 'Tegal Gede (68124)'),
(212, 'SumberSari', 'Wirolegi (68124)'),
(213, 'SumberSari', 'Antirogo (68125)'),
(214, 'SumberSari', 'Keranjingan (68126)'),
(215, 'Tanggul', 'Darungan (68155)'),
(216, 'Tanggul', 'Klatakan (68155)'),
(217, 'Tanggul', 'Kramat Sukoharjo (68155)'),
(218, 'Tanggul', 'Manggisan (68155)'),
(219, 'Tanggul', 'Patemon (68155)'),
(220, 'Tanggul', 'Selodakon (68155)'),
(221, 'Tanggul', 'Tanggul Kulon (68155)'),
(222, 'Tanggul', 'Tanggul Wetan (68155)'),
(223, 'Tempurejo', 'Andongrejo (68173)'),
(224, 'Tempurejo', 'Curahnongko (68173)'),
(225, 'Tempurejo', 'Curahtakir (68173)'),
(226, 'Tempurejo', 'Pondokrejo (68173)'),
(227, 'Tempurejo', 'Sanenrejo (68173)'),
(228, 'Tempurejo', 'Sidodadi (68173)'),
(229, 'Tempurejo', 'Tempurejo (68173)'),
(230, 'Tempurejo', 'Wonoasri (68173)'),
(231, 'Umbulsari', 'Gadingrejo (68166)'),
(232, 'Umbulsari', 'Gunungsari (68166)'),
(233, 'Umbulsari', 'Mundurejo (68166)'),
(234, 'Umbulsari', 'Paleran (68166)'),
(235, 'Umbulsari', 'Sidorejo (68166)'),
(236, 'Umbulsari', 'Sukoreno (68166)'),
(237, 'Umbulsari', 'Tanjungsari (68166)'),
(238, 'Umbulsari', 'Tegal Wangi (68166)'),
(239, 'Umbulsari', 'Umbulrejo (68166)'),
(240, 'Umbulsari', 'Umbulsari (68166)'),
(241, 'Wuluhan', 'Ampel (68162)'),
(242, 'Wuluhan', 'Dukuh Dempok (68162)'),
(243, 'Wuluhan', 'Glundengan (68162)'),
(244, 'Wuluhan', 'Kesilir (68162)'),
(245, 'Wuluhan', 'Lojejer (68162)'),
(246, 'Wuluhan', 'Tamansari (68162)'),
(247, 'Wuluhan', 'Tanjung Rejo (68162)');

-- --------------------------------------------------------

--
-- Table structure for table `layanan`
--

DROP TABLE IF EXISTS `layanan`;
CREATE TABLE IF NOT EXISTS `layanan` (
  `kd_layanan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_layanan` text NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`kd_layanan`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `layanan`
--

INSERT INTO `layanan` (`kd_layanan`, `nama_layanan`, `ket`) VALUES
(1, 'Pembuatan KTP-El Baru', ''),
(2, 'Pembuatan Akta Kelahiran', ''),
(3, 'Pencetakan KIA', '');

-- --------------------------------------------------------

--
-- Table structure for table `permohonan`
--

DROP TABLE IF EXISTS `permohonan`;
CREATE TABLE IF NOT EXISTS `permohonan` (
  `kd_reg` varchar(99) NOT NULL,
  `tanggal` timestamp NOT NULL,
  `nik` text NOT NULL,
  `nama` text NOT NULL,
  `alamat` text NOT NULL,
  `rt` text NOT NULL,
  `rw` text NOT NULL,
  `desa` text NOT NULL,
  `kec` text NOT NULL,
  `kd_layanan` int(11) NOT NULL,
  `status` text NOT NULL,
  `tgl_status` date NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`kd_reg`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permohonan`
--

INSERT INTO `permohonan` (`kd_reg`, `tanggal`, `nik`, `nama`, `alamat`, `rt`, `rw`, `desa`, `kec`, `kd_layanan`, `status`, `tgl_status`, `ket`) VALUES
('1-F83/2018/09/1', '2018-09-20 06:26:55', '3509021307990002', 'Syaikhu Rizal', 'Jalan Mayjen Suparman Dusun Krajan C', '24', '25', 'Wonorejo', 'Kencong', 1, 'PROSES', '0000-00-00', '<p>Sedang Proses Pencetakan</p>'),
('2-5A3/2018/09/2', '2018-09-20 06:27:54', '3509022209160002', 'Syaiful Rizal', 'Jl KH Hajar Dewantara', '10', '11', 'Jombang', 'Jombang', 2, 'SELESAI', '2018-09-20', '<p>Bisa Diambil Di Kantor Dispenduk Jember</p>');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

DROP TABLE IF EXISTS `petugas`;
CREATE TABLE IF NOT EXISTS `petugas` (
  `kd_petugas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_petugas` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `kd_layanan` int(11) NOT NULL,
  `ket` text NOT NULL,
  PRIMARY KEY (`kd_petugas`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`kd_petugas`, `nama_petugas`, `username`, `password`, `kd_layanan`, `ket`) VALUES
(1, 'Mas Gambris', 'admin', 'c93ccd78b2076528346216b3b2f701e6', 1, ''),
(3, 'Syaikhu Rizal', 'saiku', '2caba5547d19ae74a9b6e0dd84188a7d', 2, ''),
(9, 'Orang Baru', 'newmen', 'newmen', 1, ''),
(10, 'yuhu', 'yuhu', 'b7f68bb19bde0d7787e67053b4acd3b9', 1, '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
